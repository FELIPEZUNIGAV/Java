SELECT max(stock) mayor_cantidad_stock , NombreProducto
FROM cafeteria.productos 
