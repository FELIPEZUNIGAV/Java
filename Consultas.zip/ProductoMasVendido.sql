select max(cantidad) Producto_mas_vendido , p.NombreProducto
from cafeteria.detalleventa dv , cafeteria.productos p